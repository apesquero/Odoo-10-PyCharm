CREATE VIEW report_stock_lines_date AS SELECT p.id,
    p.id AS product_id,
    max(s.date) AS date,
    max(m.date) AS move_date,
    p.active
   FROM ((product_product p
     LEFT JOIN (stock_inventory_line l
     JOIN stock_inventory s ON (((l.inventory_id = s.id) AND ((s.state)::text = 'done'::text)))) ON ((p.id = l.product_id)))
     LEFT JOIN stock_move m ON (((m.product_id = p.id) AND ((m.state)::text = 'done'::text))))
  GROUP BY p.id;
