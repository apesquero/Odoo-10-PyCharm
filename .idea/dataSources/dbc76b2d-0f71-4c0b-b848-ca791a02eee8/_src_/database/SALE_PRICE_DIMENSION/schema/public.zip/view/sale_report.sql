CREATE VIEW sale_report AS WITH currency_rate AS (
         SELECT r.currency_id,
            COALESCE(r.company_id, c.id) AS company_id,
            r.rate,
            r.name AS date_start,
            ( SELECT r2.name
                   FROM res_currency_rate r2
                  WHERE ((r2.name > r.name) AND (r2.currency_id = r.currency_id) AND ((r2.company_id IS NULL) OR (r2.company_id = c.id)))
                  ORDER BY r2.name
                 LIMIT 1) AS date_end
           FROM (res_currency_rate r
             JOIN res_company c ON (((r.company_id IS NULL) OR (r.company_id = c.id))))
        )
 SELECT min(l.id) AS id,
    l.product_id,
    t.uom_id AS product_uom,
    sum(((l.product_uom_qty / u.factor) * u2.factor)) AS product_uom_qty,
    sum(((l.qty_delivered / u.factor) * u2.factor)) AS qty_delivered,
    sum(((l.qty_invoiced / u.factor) * u2.factor)) AS qty_invoiced,
    sum(((l.qty_to_invoice / u.factor) * u2.factor)) AS qty_to_invoice,
    sum((l.price_total / COALESCE(cr.rate, 1.0))) AS price_total,
    sum((l.price_subtotal / COALESCE(cr.rate, 1.0))) AS price_subtotal,
    count(*) AS nbr,
    s.name,
    s.date_order AS date,
    s.state,
    s.partner_id,
    s.user_id,
    s.company_id,
    (date_part('epoch'::text, avg((date_trunc('day'::text, s.date_order) - date_trunc('day'::text, s.create_date)))) / ((((24 * 60) * 60))::numeric(16,2))::double precision) AS delay,
    t.categ_id,
    s.pricelist_id,
    s.project_id AS analytic_account_id,
    s.team_id,
    p.product_tmpl_id,
    partner.country_id,
    partner.commercial_partner_id,
    sum((((p.weight * l.product_uom_qty) / u.factor) * u2.factor)) AS weight,
    sum((((p.volume * (l.product_uom_qty)::double precision) / (u.factor)::double precision) * (u2.factor)::double precision)) AS volume
   FROM ((((((((sale_order_line l
     JOIN sale_order s ON ((l.order_id = s.id)))
     JOIN res_partner partner ON ((s.partner_id = partner.id)))
     LEFT JOIN product_product p ON ((l.product_id = p.id)))
     LEFT JOIN product_template t ON ((p.product_tmpl_id = t.id)))
     LEFT JOIN product_uom u ON ((u.id = l.product_uom)))
     LEFT JOIN product_uom u2 ON ((u2.id = t.uom_id)))
     LEFT JOIN product_pricelist pp ON ((s.pricelist_id = pp.id)))
     LEFT JOIN currency_rate cr ON (((cr.currency_id = pp.currency_id) AND (cr.company_id = s.company_id) AND (cr.date_start <= COALESCE((s.date_order)::timestamp with time zone, now())) AND ((cr.date_end IS NULL) OR (cr.date_end > COALESCE((s.date_order)::timestamp with time zone, now()))))))
  GROUP BY l.product_id, l.order_id, t.uom_id, t.categ_id, s.name, s.date_order, s.partner_id, s.user_id, s.state, s.company_id, s.pricelist_id, s.project_id, s.team_id, p.product_tmpl_id, partner.country_id, partner.commercial_partner_id;
